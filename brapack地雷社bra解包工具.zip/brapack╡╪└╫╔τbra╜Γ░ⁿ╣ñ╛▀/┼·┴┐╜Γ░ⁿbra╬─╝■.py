import os
import subprocess

# 设置解包工具的路径为当前脚本所在目录
brapack_path = os.path.join(os.path.dirname(__file__), 'brapack.exe')

def extract_bra_file(brapack_path, bra_file_path):
    # 使用 brapack.exe 解包 bra 文件
    command = [brapack_path, bra_file_path]
    try:
        subprocess.run(command, check=True)
        print(f"Extracted: {bra_file_path}")
    except subprocess.CalledProcessError as e:
        print(f"Failed to extract {bra_file_path}: {e}")

def process_files(src_folder):
    # 遍历文件夹及子文件夹，查找 .bra 文件
    for root, dirs, files in os.walk(src_folder):
        for file in files:
            if file.lower().endswith('.bra'):
                bra_file_path = os.path.join(root, file)
                # 执行解包操作
                extract_bra_file(brapack_path, bra_file_path)

# 从用户输入获取源文件夹路径
src_folder = input("请输入源文件夹路径：")

# 确保源文件夹存在
if not os.path.exists(src_folder):
    print(f"源文件夹不存在：{src_folder}")
    exit(1)

# 处理解包操作
print("开始解包 .bra 文件...")
process_files(src_folder)
print("所有文件处理完成。")