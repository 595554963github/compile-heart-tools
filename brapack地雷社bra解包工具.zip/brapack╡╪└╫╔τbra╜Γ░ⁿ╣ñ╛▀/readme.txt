Compile Heart BRA Unpacker/Packer
=================================
Program to unpack and repack '*.bra' files used in Compile Heart games.
Tested with "Mugen Souls" and "Agarest: Generations of War".

//RikuKH3
