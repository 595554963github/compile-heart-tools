import os
import zlib
import subprocess

def decompress_file(file_path):
    try:
        with open(file_path, 'rb') as file:
            content = file.read()
            # 检查文件头
            if content.startswith(b'ZLIB'):
                # 查找第一个 78 DA 的字节序列
                index = content.find(b'\x78\xDA')
                
                if index != -1:
                    # 删除该序列前面的所有内容
                    content_to_decompress = content[index:]
                    
                    # 尝试解压文件
                    try:
                        decompressed_data = zlib.decompress(content_to_decompress)
                    except zlib.error as e:
                        print(f"Error decompressing file {file_path}: {e}")
                        return None
                    
                    # 创建新文件名
                    new_file_path = f"{os.path.splitext(file_path)[0]}_decompressed{os.path.splitext(file_path)[1]}"
                    print(f"File {file_path} has been decompressed to {new_file_path}")
                    
                    # 保存解压后的数据到新文件
                    with open(new_file_path, 'wb') as new_file:
                        new_file.write(decompressed_data)
                    
                    return new_file_path  # 返回新文件路径
                else:
                    print(f"File {file_path} does not contain the required sequence.")
                    return None
            else:
                print(f"File {file_path} does not have the ZLIB header.")
                return file_path  # 如果不是ZLIB开头，直接返回原始文件路径
    except Exception as e:
        print(f"Error processing file {file_path}: {e}")
        return None

def extract_file(tool_path, file_path):
    # 使用工具解压文件，构建命令行命令
    command = [tool_path, file_path]
    try:
        subprocess.run(command, check=True)
        print(f"Extracted: {file_path}")
    except subprocess.CalledProcessError as e:
        print(f"Failed to extract {file_path}: {e}")

def process_files(src_folder, tool_path, file_extension):
    # 遍历文件夹及子文件夹，查找指定类型的文件
    for root, dirs, files in os.walk(src_folder):
        for file in files:
            if file.lower().endswith(file_extension):
                file_path = os.path.join(root, file)
                # 处理解压缩
                decompressed_file_path = decompress_file(file_path)
                if decompressed_file_path:
                    # 解压新文件
                    extract_file(tool_path, decompressed_file_path)

# 获取当前脚本所在目录
current_dir = os.path.dirname(__file__)

# 从用户输入获取源文件夹路径
src_folder = input("请输入源文件夹路径：")

# 确保源文件夹存在
if not os.path.exists(src_folder):
    print(f"源文件夹不存在：{src_folder}")
    exit(1)

# 让用户选择解压方式
choice = input("请选择解压方式 (1=PCK, 2=TEX): ")
if choice == '1':
    file_extension = '.pck'
    tool_path = os.path.join(current_dir, 'PCKTool.exe')
elif choice == '2':
    file_extension = '.tex'
    tool_path = os.path.join(current_dir, 'TEXTool.exe')
else:
    print("无效的选择。")
    exit(1)

# 解压文件
print("正在处理文件...")
process_files(src_folder, tool_path, file_extension)
print("所有文件已处理完成。")