import os
import shutil

def find_bc7_tid_files(src_folder):
    # 定义文件头和BC7纹理格式的字节序列
    file_header = b'TID'
    byte_sequence = b'BC7'
    
    # 存储找到的BC7纹理的tid文件路径
    bc7_tid_files = []
    
    # 遍历文件夹及子文件夹
    for root, dirs, files in os.walk(src_folder):
        for file in files:
            if file.lower().endswith('.tid'):
                file_path = os.path.join(root, file)
                try:
                    with open(file_path, 'rb') as f:
                        content = f.read(128)  # 读取文件的前128个字节
                        if content.startswith(file_header):
                            # 如果找到了文件头，查找BC7序列
                            index = content.find(byte_sequence)
                            if index != -1:
                                # 找到BC7纹理的tid文件，添加到列表中
                                bc7_tid_files.append(file_path)
                except Exception as e:
                    print(f"无法读取文件 {file_path}: {e}")
    
    return bc7_tid_files

def move_bc7_tid_files(bc7_tid_files, dest_folder):
    for file_path in bc7_tid_files:
        try:
            # 移动文件到目标文件夹
            dest_path = os.path.join(dest_folder, os.path.basename(file_path))
            shutil.move(file_path, dest_path)
            print(f"Moved: {file_path} to {dest_path}")
        except Exception as e:
            print(f"无法移动文件 {file_path}: {e}")

# 从用户输入获取源文件夹和目标文件夹路径
src_folder = input("请输入源文件夹路径：")
dest_folder = input("请输入目标文件夹路径：")

# 确保目标文件夹存在
if not os.path.exists(dest_folder):
    os.makedirs(dest_folder)

# 查找BC7纹理的tid文件
bc7_tid_files = find_bc7_tid_files(src_folder)

# 移动BC7纹理的tid文件
move_bc7_tid_files(bc7_tid_files, dest_folder)

# 输出移动的文件
print(f"移动了以下文件：")
for file_path in bc7_tid_files:
    print(file_path)
