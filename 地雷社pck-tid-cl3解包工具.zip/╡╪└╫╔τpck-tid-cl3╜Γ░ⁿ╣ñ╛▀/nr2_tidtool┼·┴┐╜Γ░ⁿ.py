import os
import subprocess
from concurrent.futures import ThreadPoolExecutor

# 解包文件函数
def unpack_tid_file(file_path):
    try:
        print(f"开始解包: {file_path}")
        # 运行nr2_tidtool解包文件
        subprocess.run(['nr2_tidtool', file_path], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        # 检查解包后是否存在同名png文件
        tid_name = os.path.splitext(file_path)[0]
        png_file = tid_name + '.png'
        if os.path.exists(png_file):
            print(f"解包成功，找到同名PNG文件: {png_file}")
            # 删除原始tid文件
            os.remove(file_path)
        else:
            print("解包失败，没有找到同名的PNG文件。")
            return False
        return True
    except subprocess.CalledProcessError as e:
        print(f"解包失败: {file_path}，错误: {e.stderr}")
        return False

# 遍历文件夹及其子文件夹，并解包tid文件
def select_and_unpack():
    folder_path = input("请输入包含.tid文件的文件夹路径：")
    
    if not os.path.isdir(folder_path):
        print("输入的路径不是一个有效的文件夹，请输入一个有效的路径。")
        return

    tid_files = [os.path.join(root, file) for root, dirs, files in os.walk(folder_path) for file in files if file.endswith('.tid')]
    print(f"找到 {len(tid_files)} 个 .tid 文件。")

    unpacked_files = 0
    failed_files = 0

    # 使用线程池处理文件
    with ThreadPoolExecutor(max_workers=10) as executor:
        results = executor.map(unpack_tid_file, tid_files)
        for result in results:
            if result:
                unpacked_files += 1
            else:
                failed_files += 1

    print(f"解包完成。成功解包 {unpacked_files} 个文件。")
    print(f"失败解包 {failed_files} 个文件。")

# 主函数
if __name__ == "__main__":
    select_and_unpack()