import tkinter as tk
from tkinter import filedialog
import subprocess
import os
from concurrent.futures import ThreadPoolExecutor

# 解压文件函数
def extract_file(file_path, file_type):
    try:
        print(f"开始解压: {file_path}")
        # 等待解压完成并获取输出
        process = subprocess.Popen(['Multi Extractor.exe', file_path], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        stdout, stderr = process.communicate()
        print(stdout, end='')  # 打印输出到控制台
        if stderr:
            print(f"解压错误: {stderr}", end='')
            return False
        return True
    except Exception as e:
        print(f"解压失败: {file_path}，错误: {e}")
        return False

# 解压cl3文件
def extract_cl3():
    folder_path = filedialog.askdirectory()
    if folder_path:
        files_to_extract = []
        for root, dirs, files in os.walk(folder_path):
            for file in files:
                if file.endswith('.cl3'):
                    files_to_extract.append(os.path.join(root, file))

        # 每批处理文件的数量
        batch_size = 100  # 根据系统资源调整这个值

        # 创建线程池
        with ThreadPoolExecutor(max_workers=10) as executor:
            for i in range(0, len(files_to_extract), batch_size):
                batch = files_to_extract[i:i + batch_size]
                # 使用线程池处理每批文件
                for file_path in batch:
                    if extract_file(file_path, 1):
                        # 解压成功后删除原始cl3文件
                        os.remove(file_path)
                        print(f"原始文件已删除: {file_path}")

# 解包tid文件
def extract_tid():
    folder_path = filedialog.askdirectory()
    if folder_path:
        files_to_extract = []
        for root, dirs, files in os.walk(folder_path):
            for file in files:
                if file.endswith('.tid'):
                    files_to_extract.append(os.path.join(root, file))

        # 每批处理文件的数量
        batch_size = 100  # 根据系统资源调整这个值

        # 创建线程池
        with ThreadPoolExecutor(max_workers=10) as executor:
            for i in range(0, len(files_to_extract), batch_size):
                batch = files_to_extract[i:i + batch_size]
                # 使用线程池处理每批文件
                for file_path in batch:
                    if extract_file(file_path, 2):
                        # 解包成功后检查同名PNG文件
                        tid_name = os.path.splitext(file_path)[0]
                        png_file = tid_name + '.png'
                        if os.path.exists(png_file):
                            print(f"同名PNG文件存在: {png_file}")
                            os.remove(file_path)
                            print(f"原始文件已删除: {file_path}")
                        else:
                            print("同名PNG文件不存在，未删除原始文件。")

# 创建主窗口
root = tk.Tk()
root.title("批量解压工具")
root.geometry('400x200')

# 添加按钮
button_cl3 = tk.Button(root, text="解压CL3文件", command=extract_cl3)
button_cl3.pack(pady=10)

button_tid = tk.Button(root, text="解包TID文件", command=extract_tid)
button_tid.pack(pady=10)

# 运行主循环
root.mainloop()